.. _interpolator:


Interpolator
---------------

.. autofunction:: pyconturb._utils.interpolator
