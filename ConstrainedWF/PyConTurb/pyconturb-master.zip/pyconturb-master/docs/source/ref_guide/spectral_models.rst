.. _spectral_models:


Turbulence spectra
------------------------------

.. automodule:: pyconturb.spectral_models
   :members: get_spec_values, kaimal_spectrum, data_spectrum


