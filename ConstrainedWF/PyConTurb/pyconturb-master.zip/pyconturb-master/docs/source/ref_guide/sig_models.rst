.. _sig_models:


Turbulence standard deviation
------------------------------

.. automodule:: pyconturb.sig_models
   :members: get_sig_values, iec_sig, data_sig

