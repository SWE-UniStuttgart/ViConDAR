.. _gen_turb:


Generating turbulence
----------------------

.. automodule:: pyconturb
   :members: gen_turb
