.. _time_constraint:


TimeConstraint
---------------

This is the object to be used when defining time constraints
for a simulation.

.. autoclass:: pyconturb.TimeConstraint
    :members:
