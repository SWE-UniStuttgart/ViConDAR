.. _profiles:


Mean wind speed profiles
--------------------------

.. automodule:: pyconturb.wind_profiles
   :members: get_wsp_values, constant_profile, power_profile, data_profile


