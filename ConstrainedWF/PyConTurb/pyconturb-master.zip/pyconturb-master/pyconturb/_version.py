#   version:    1.0     First pass at PyConTurb
#               2.0     Switch to uvw, other changes
#                2.5    Fixed bug in custom profiles
__version__ = '2.5.dev1'
__release__ = '2.5.dev1'
