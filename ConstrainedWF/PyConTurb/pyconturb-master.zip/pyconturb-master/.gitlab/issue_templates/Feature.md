# Feature request

## Summary

What is the goal of this feature? Why should it be added?

## Pseudocode

Put some pseudocode here to show how this feature would work.
```
<place code here>
```

## Suggested implementation

If you have any ideas of how to implement the feature, put those
here.
